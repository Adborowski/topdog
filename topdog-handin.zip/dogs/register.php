<?php include "header.php" ?>

<?php include "components/comp-register/comp-register.php" ?>  

<?php include "footer.php" ?>