<?php include "header.php" ?>

<?php include "components/comp-navigation/comp-navigation.php" ?>

<?php include "components/comp-dog-viewer/comp-dog-viewer.php"?>

<?php include "components/comp-popup/comp-popup.php"?>

<?php include "footer.php" ?>