<?php

echo "<div style='opacity: 0.1' id='boxCopyright'>&copy Adam Borowski 2020</div>";

?>

</body>



</html>