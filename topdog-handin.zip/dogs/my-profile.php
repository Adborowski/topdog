<?php include "header.php" ?>

<?php include "components/comp-navigation/comp-navigation.php" ?>

<div id="" class="main">

    <?php include "components/comp-user-profile/comp-user-profile.php" ?>
    <?php include "components/comp-questions-human/comp-questions-human.php" ?>
    
</div>

<?php include "footer.php" ?>