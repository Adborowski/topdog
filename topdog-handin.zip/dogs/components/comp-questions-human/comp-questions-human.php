<div class="frameHeadline">
    Your answers
</div>

<div id="boxQuestionsHuman">

    <!-- <div class="questionModule" data-question-id="1">
        <div class="questionContent">Are you confident that you really exist?</div>
        <div class="questionControls">
            <div class="btn btn-question-control" data-answer-value=1><div class="buttonLabel">YES</div></div>
            <div class="btn btn-question-control" data-answer-value=0><div class="buttonLabel">?</div></div>
            <div class="btn btn-question-control" data-answer-value=-1><div class="buttonLabel">NO</div></div>
        </div>
    </div> -->

</div>

<script src="components/comp-questions-human/comp-questions-human.js"></script>