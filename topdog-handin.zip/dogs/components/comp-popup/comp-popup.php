<div id="popupModal">

    <div id="popupFrame">

        <div id="popupTitle">Hardcode Title</div>
        <div id="popupContent">Hardcode Content</div>
        <div id="popupControls">
            <div id="btn-popup-ok" class="btn btn-primary btn-popup-control">OK</div>
        </div>

    </div>

</div>

<script src="components/comp-popup/comp-popup.js"></script>