<div class="compFrame fadeIn" id="dogProfile"> 


<script src="components/comp-dog-profile/comp-dog-profile.js"></script>


