<div class="frameHeadline">
    Your top dogs
</div>

<div class="" id="dogViewer"> 

    <!-- <div class="compFrame dogCard">
        <div class="dogDetail dogPictureFrame">
            <img src="assets/images/dogs/1.jpg" alt="">
        </div>
        <div class="boxDogId">1</div>
        <div class="dogDetail">HARDCODE</div>
        <div class="dogDetail">I AM HARDCODED</div>
        <div class="btn btn-primary dogDetail">Add to Favorites</div>
    </div> -->

</div>

<script src="components/comp-dog-viewer/comp-dog-viewer.js"></script>


