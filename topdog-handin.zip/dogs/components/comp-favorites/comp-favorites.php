<div class="frameHeadline">
    Your favorites
</div>

<div class="favoritesViewer" id="dogViewer"></div>

<script src="components/comp-favorites/comp-favorites.js"></script>