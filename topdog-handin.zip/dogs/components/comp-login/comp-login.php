<?php

// if there's a username and a password in the session, use them instead of logging in
session_start();
if (!empty($_SESSION["activeUsername"]) && !empty($_SESSION["activePassword"])){
    header("Location: user-page.php");
};

?>

<div id="mainLogin">

    <div id="compLogin" class="fadeIn compFrame">

        <?php include("components/comp-logotype/comp-logotype.php") ?>

        <input class="txtInput" id="txtUsername" placeholder="Your username" value="admin"></input>
        <input class="txtInput" type="password" id="txtPassword" placeholder="Your password" value="password"></input>
                
        <div id="btnLogin" class="btn btn-primary"><div>LOG IN</div></div>

        <div class="btn"><a href="register.php" >Create account</a></div>

    </div>

    <script src="components/comp-login/comp-login.js"></script>

</div>



