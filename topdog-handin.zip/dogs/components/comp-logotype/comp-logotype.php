<a href="index.php" class="logotypeFrame">

    <div class="logoFrame">
        <img src="assets/logo/logo2.svg" alt="" class="imgLogo"></img>
    </div>

    <div class="appNameFrame">
        <div class="appName">Topdog</div>
    </div>

</a>