<?php include "header.php" ?>

<?php include "components/comp-navigation/comp-navigation.php" ?>
<?php include "components/comp-video-browser/comp-video-browser.php" ?>

<?php include "footer.php" ?>